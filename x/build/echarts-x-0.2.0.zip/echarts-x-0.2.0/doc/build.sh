node build.js
lessc css/article.less > css/article.css
lessc css/common.less > css/common.css
lessc css/index.less > css/index.css
lessc css/example_entry.less > css/example_entry.css